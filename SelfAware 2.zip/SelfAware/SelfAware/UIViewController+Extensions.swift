//
//  UIViewController+Extensions.swift
//  SelfAware
//
//  Created by Sadia on 22/04/2024.
//

import Foundation
import UIKit

extension UIViewController {
    @IBAction func unwind(_ segue: UIStoryboardSegue) {}
}
