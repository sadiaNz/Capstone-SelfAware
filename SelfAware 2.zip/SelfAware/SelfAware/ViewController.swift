//
//  ViewController.swift
//  SelfAware
//
//  Created by Sadia on 12/04/2024.
//

import UIKit
import Firebase;
import FirebaseAuth;
import FirebaseCore;
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var signupemail: UITextField!
    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var logText: UILabel!

    @IBOutlet weak var passwordsignup: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func signTest(_ sender: Any) 
    {
        print("signTest")
 
        if(emailField.text != "" && password.text != "")
        {
            if(isValidEmail(emailField.text!))
            {
                singin(emailField.text!, password.text!);
            }
            else
            {
                message.text = "Invalid email address";
            }
        }
    }
   

    @IBAction func signinbutton(_ sender: Any) 
    {
      
        print("signunbutton")
        
        if(signupemail.text! != "" && passwordsignup.text! != "")
        {
            if(isValidEmail(signupemail.text!))
            {
                if(isValidPassword(passwordsignup.text!))
                {
                    logText.text = "";
     
                       signupEmail(signupemail.text!,passwordsignup.text!);
                    
                    dismiss(animated: true)

                }
                else
                {
                    logText.text = "password should be greater than 6..";
                }
            }
            else
            {
                logText.text = "email format is incorrect";
            }
        }
        else
        {
            logText.text = "Empty fields";
        }
    }
    func signupEmail(_ email:String, _ password:String)
    {
        let email = email
        let password = password
        var returnString = ""
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
                    
            if let maybeError = error { //if there was an error, handle it
                let err = maybeError as NSError
                switch err.code {
                case AuthErrorCode.wrongPassword.rawValue:
                    print("wrong password")
                    returnString = "wrong password";
                    ViewController().alert(message: "Oops!",title: returnString);
                case AuthErrorCode.invalidEmail.rawValue:
                    print("invalid email")
                    returnString = "invalid email";
                    ViewController().alert(message: "Oops!",title: returnString);
                case AuthErrorCode.accountExistsWithDifferentCredential.rawValue:
                    print("accountExistsWithDifferentCredential")
                    returnString = "account Exists With Different Credential";
                    ViewController().alert(message: "Oops!",title: returnString);
               // ... add the rest of the case statements
                default:
                    print("unknown error: \(err.localizedDescription)")
                    returnString = err.localizedDescription;
                    ViewController().alert(message: "Oops!",title: returnString);
                   
                }
            }
            else
            { //there was no error so the user could be auth'd or maybe not!
             print("no error")
                Auth.auth().currentUser?.sendEmailVerification { error in
                    print("Your email is pending verification, please check your emails for a verification link.")
                    returnString = "Your email is pending verification, please check your emails for a verification link.";
                    self.alert(message: "Message",title: returnString);
                  //  self.message.text = returnString;
                }
                self.alert(message: "Congratulation",title: "sign up");
            }
        }

    }
    func singin(_ email:String, _ password:String)
    {
        let email = email
        let password = password
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            if( error != nil)
            {
                print("Error \(error!.localizedDescription)")
                self.alert(message: error!.localizedDescription,title: "error");
            }
            else
            {
                let newUserInfo = Auth.auth().currentUser
                let email = newUserInfo?.email
                self.alert(message: "login successful",title: "Welcome");
               
            }
        }

    }
    func isValidEmail(_ email: String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
      
    func isValidPassword(_ password: String) -> Bool
    {
        let minPasswordLength = 6
        return password.count >= minPasswordLength
    }
    func signout()
    {
        do
        {
          try Auth.auth().signOut()
        }
        catch
        {
          print("Sign out error")
        }
    }

                    

    
}

