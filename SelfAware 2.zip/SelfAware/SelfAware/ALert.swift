//
//  ALert.swift
//  SelfAware
//
//

import Foundation
import UIKit

extension UIViewController {
    func alert(message: String, title: String = "") {
        DispatchQueue.main.async {
            let myAlert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            myAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (actin) in
                myAlert.dismiss(animated: true, completion: nil)
                self.navigationController?.popViewController(animated: true)
            }))
            self.present(myAlert, animated: true, completion: nil)
        }
    }
}
